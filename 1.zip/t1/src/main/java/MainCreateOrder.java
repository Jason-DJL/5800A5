import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;

public class MainCreateOrder {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure();

        SessionFactory sessionFactory = cfg.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Product p1 = new Product();
        p1.setName("product1");
        Product p2 = new Product();
        p2.setName("product2");
        session.save(p1);
        session.save(p2);

        Order o = new Order();
        Query query = session.createQuery("from Product");
        query.list().forEach(q -> {
            Product p = (Product) q;
            o.getProducts().add(p);
        });
        o.setCustomerName("Customer");
        o.setDate(new Date());
        session.save(o);

        tx.commit();
        session.close();
        sessionFactory.close();
    }
}
