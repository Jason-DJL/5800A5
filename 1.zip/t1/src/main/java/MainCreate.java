import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainCreate {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure();

        SessionFactory sessionFactory = cfg.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Customer c = new Customer();
        c.setName("Tom");
        c.setAddress("Sichuan");

        Professor p = new Professor();
        p.setOfficeNumber("123");
        p.setResearchArea("CS");
        p.setCustomer(c);
        session.save(p);

        tx.commit();
        session.close();
        sessionFactory.close();
    }
}
