import org.junit.Assert;
import org.junit.Test;

public class PrimeTest {
    private Prime p = new Prime();

    @Test
    public void test2() {
        Assert.assertTrue(p.isPrime(2));
    }

    @Test
    public void test3() {
        Assert.assertTrue(p.isPrime(3));
    }

    @Test
    public void test4() {
        Assert.assertTrue(p.isPrime(4));
    }

    @Test
    public void test5() {
        Assert.assertTrue(p.isPrime(5));
    }

    @Test
    public void test6() {
        Assert.assertTrue(p.isPrime(6));
    }
}
